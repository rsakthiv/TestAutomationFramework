package init;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import constants.AppConfig;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {
	public RemoteWebDriver driver;
	private static ThreadLocal<RemoteWebDriver> webDriver = new ThreadLocal<RemoteWebDriver>();
	public DesiredCapabilities capability;
	private static Logger log = Logger.getLogger(DriverFactory.class);

	public DriverFactory() {

		capability = new DesiredCapabilities();
		switch (AppConfig.browser) {
		case "chrome":
			if (!AppConfig.remoteExecution.equals("true")) {
				WebDriverManager.chromedriver().setup();
				setDriver(new ChromeDriver());

			} else {
				try {
					capability.setBrowserName(AppConfig.browser);
					setDriver(new RemoteWebDriver(new URL("http://www.localhost:4444/wd/hub"), capability));
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}

			}
			break;

		case "firefox":
			if (!AppConfig.remoteExecution.equals("true")) {
				WebDriverManager.chromedriver().setup();
				setDriver(new FirefoxDriver());

			} else {
				try {
					capability.setBrowserName(AppConfig.browser);
					setDriver(new RemoteWebDriver(new URL("http://www.localhost:4445/wd/hub"), capability));
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}

			}
			break;

		default:
			throw new RuntimeException("please check your browser...");
		}
		log.info("Driver intitialized for " + AppConfig.browser + "...");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	public void setup() {
		WebDriverManager.chromedriver().setup();
	}

	public static RemoteWebDriver getDriver() {
		return webDriver.get();

	}

	public void setDriver(RemoteWebDriver driver) {
		webDriver.set(driver);
	}

}
