package constants;

import utils.FileOperations;

public interface AppConfig {

	 String browser=FileOperations.getConfig("browser");
	 String port=FileOperations.getConfig("port");
	 String path=FileOperations.getConfig("path");
	 String url=FileOperations.getConfig("url");
	 String remoteExecution =FileOperations.getConfig("remoteExecution");

}
