package constants;

public interface Path {
	 String CONFIG_WEB_FILE_PATH = "src/main/java/config/AppConfig.properties";
	 String CONFIG_LOG4J_FILE_PATH = "src/main/java/config/log4j.properties";
	 
	 
	 

}
