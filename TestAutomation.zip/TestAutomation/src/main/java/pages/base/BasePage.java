package pages.base;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {
	
	private final int WAIT_FOR_SECONDS = 80;
	Logger log=null;
	
	public BasePage() {
		log=Logger.getLogger(BasePage.class);
	}
	
	public void waitForElementVisibility(RemoteWebDriver driver, By locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, WAIT_FOR_SECONDS);
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
		webDriverWait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
		webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public void waitForElementClickability(RemoteWebDriver driver, By locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, WAIT_FOR_SECONDS);
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
		webDriverWait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public void click(RemoteWebDriver driver, By locator) {
		waitForElementVisibility(driver, locator);
		driver.findElement(locator).click();
		log.info("Click action performed successfully on element "+driver);

	}

	public void enterData(RemoteWebDriver driver, By locator, String value) {
		waitForElementClickability(driver, locator);
		hardWait(1000);
		driver.findElement(locator).click();
		hardWait(1000);
		driver.findElement(locator).clear();
		hardWait(2000);
		driver.findElement(locator).sendKeys(value);
		log.info("Entered value successfully on element "+driver);


	}

	public void hardWait(int milliSeconds) {
		try {
			Thread.sleep(milliSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void clickList(RemoteWebDriver driver, By locator,String listName) {
		driver.findElements(locator).forEach(e->{
			if (e.getText().equals(listName)) 
				e.click();
			
		});
	}
	
	public String getText(RemoteWebDriver driver, By locator) {
		waitForElementVisibility(driver, locator);
		return driver.findElement(locator).getText();
		
	}
	
	public void switchWindows(RemoteWebDriver driver ,int index) {
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(index));
	}
	
	public void closeCurrentWindow(RemoteWebDriver driver) {
		driver.close();
		
	}
}
