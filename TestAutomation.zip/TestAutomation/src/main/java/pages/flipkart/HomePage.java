package pages.flipkart;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import pages.base.BasePage;

public class HomePage extends BasePage{
	By closeIcon=By.xpath("//button[text()='✕']");
	By searchProductsField=By.cssSelector("input[title*='Search for products']");
	By searchIcon=By.cssSelector("button[type='submit']");
	By productList=By.cssSelector("div._4rR01T");
	By priceTag=By.cssSelector("._30jeq3._16Jk6d");
	
	By buyProductBtn=By.xpath("//button[text()='BUY NOW']");
	By continueBtn=By.xpath("//span[text()='CONTINUE']");
	
	
	public void closeCrossIcon(RemoteWebDriver driver) {
		click(driver, closeIcon);
	}
	
	public void clickOnSearchIcon(RemoteWebDriver driver) {
		click(driver, searchIcon);
	}
	public void enterSearchProducts(RemoteWebDriver driver,String product) {
		enterData(driver, searchProductsField, product);
		
	}
	
	public void clickOnProduct(RemoteWebDriver driver,String product) {
		clickList(driver, productList, product);
	}
	
	public void clickBuyProductButton(RemoteWebDriver driver) {
		click(driver, buyProductBtn);
	}
	
	public String getProductPrice(RemoteWebDriver driver) {
		return getText(driver, priceTag);
		
	}
}
