package listner;

import java.util.Date;

import org.testng.IClassListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestClass;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import init.DriverFactory;

public class ReportListener implements ITestListener, ISuiteListener{

	@Override
	public void onStart(ISuite suite) {
		System.out.println("********************** Test Execution Started : "+new Date() +"********************");
		
	}

	@Override
	public void onFinish(ISuite suite) {
		System.out.println("****************** Test Execution Ended : "+new Date() +"******************");


		
	}



	@Override
	public void onTestStart(ITestResult result) {
		String testClassName = result.getTestClass().getRealClass().getSimpleName();
		System.out.println("class name: "+testClassName+" with instance id :"+DriverFactory.getDriver());

		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("onTestSuccess");

		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("onTestFailure");
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(ITestContext context) {

		
	}

}
