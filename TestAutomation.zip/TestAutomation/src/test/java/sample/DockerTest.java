package sample;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class DockerTest {
	
	
	@BeforeClass
	
	public void startUp() throws IOException, InterruptedException {
		Runtime.getRuntime().exec("cmd /c start dockerstart.bat ");
		Thread.sleep(5000);
		
	}
	
	@Test
	
	public void test() throws MalformedURLException {
		
		DesiredCapabilities cap= new DesiredCapabilities();
		cap.setBrowserName("chrome");
		RemoteWebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),cap);
		System.out.println("Driver : "+driver);
		driver.get("http://www.flipkart.com");
		System.out.println(driver.getTitle());
		
		driver.quit();
		
		
	}

	//@AfterClass
	
	public void tearDown() throws IOException, InterruptedException {
	
		
			Thread.sleep(5000);
			Runtime.getRuntime().exec("taskkill /f /im cmd.exe ");

		

	
}
}