package base;


import java.util.Objects;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import constants.AppConfig;
import constants.Path;
import init.DriverFactory;

public class BaseTest {
	Logger log;
	public RemoteWebDriver driver;
	public DriverFactory driverFactory;
	
	@BeforeMethod
	public void startUp() throws Exception {
		log = Logger.getLogger(BaseTest.class);
		PropertyConfigurator.configure(Path.CONFIG_LOG4J_FILE_PATH);
		driverFactory= new DriverFactory();
		this.driver=DriverFactory.getDriver();
		this.driver.get(AppConfig.url);
		log.info("URL is entered succesfully in browser");
		
	}
	
	@AfterMethod
	public void tearDown() throws Exception {

		if(Objects.nonNull(driver))
			this.driver.close();
	}
}
