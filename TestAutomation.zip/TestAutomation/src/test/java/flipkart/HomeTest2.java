package flipkart;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.flipkart.HomePage;

public class HomeTest2 extends BaseTest{
	

	HomePage homePage = new HomePage();
	String productName="realme C12 (Power Blue, 32 GB)";
	String productPrice="₹7,999";
	
	
	@Test
	public void verifySearchProduct() {
		
		homePage.closeCrossIcon(driver);
		homePage.enterSearchProducts(driver, productName);
		homePage.clickOnSearchIcon(driver);
		homePage.clickOnProduct(driver, productName);
		homePage.switchWindows(driver, 1);
		Assert.assertEquals(homePage.getProductPrice(driver), productPrice,"Product Price is not matched");
		driver.close();
		homePage.switchWindows(driver, 0);

		
	}
	
	
	@Test
	public void verifyAddToCard() {
		
		

		
	}

}
